package oracle;

public interface RecompenseInterface {
    void PunitionSansRaison(String oracle, String croyant);
    void echangerMiracleEtPunition(String oracle, String croyant);
    void ramasserDuBois(String oracle, String croyant);
}
