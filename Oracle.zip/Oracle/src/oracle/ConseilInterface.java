package oracle;

public interface ConseilInterface {
    void conseilsSansRaison(String oracle, String croyant);
    void conseilSurdemande(String demande, String oracle, String croyant);
}
