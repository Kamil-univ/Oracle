package oracle;

public interface MiracleInterface {
    void realiserMiracle(String oracle, String croyant);
    void demanderLaPluie(String oracle, String croyant);
}
